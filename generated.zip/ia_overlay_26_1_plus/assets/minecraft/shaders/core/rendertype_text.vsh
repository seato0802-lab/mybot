#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_b6a19edf(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_1828939b() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_9e2307a6(inout vec4 vertex) {
    f_b6a19edf(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_1828939b();
    }
        finalize();
}



void f_a52f9b3f() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_0712c22d() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_c712368b(inout vec4 vertex) {
    f_b6a19edf(vertex);
    f_a52f9b3f();
    finalize();
}

void f_d54865c4(inout vec4 vertex) {
    f_b6a19edf(vertex);
    f_1828939b();
    f_0712c22d();
    finalize();
}

void f_f1ce1a1c(inout vec4 vertex) {
    f_b6a19edf(vertex);
    f_0712c22d();
    f_a52f9b3f();
    finalize();
}

void f_4cf436b8(inout vec4 vertex) {
    f_1828939b();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_b6a19edf(vertex);
    finalize();
}

void f_a703177b(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_a52f9b3f();
    f_b6a19edf(vertex);
    finalize();
}

void f_1ce7087a(inout vec4 vertex, float speed) {
    f_b6a19edf(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_3af4f055(inout vec4 vertex) {
    f_b6a19edf(vertex);
    f_1828939b();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_9e2307a6(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_1828939b();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_b6a19edf(vertex);
            f_1828939b();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_d54865c4(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_d54865c4(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_4cf436b8(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_4cf436b8(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_1ce7087a(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_3af4f055(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_c712368b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_d54865c4(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_f1ce1a1c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_4cf436b8(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_a703177b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_1ce7087a(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_c712368b(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_d54865c4(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_f1ce1a1c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_4cf436b8(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_a703177b(vertex);
        return;
    }
    

    
    f_b6a19edf(vertex);
    f_1828939b();
    finalize();
}