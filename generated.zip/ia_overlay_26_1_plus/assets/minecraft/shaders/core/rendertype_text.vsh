#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_a5ab46a0(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_b5b95fe7() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_3fd892a9(inout vec4 vertex) {
    f_a5ab46a0(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_b5b95fe7();
    }
        finalize();
}



void f_aad4af2c() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_5b92effa() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_f99b6fea(inout vec4 vertex) {
    f_a5ab46a0(vertex);
    f_aad4af2c();
    finalize();
}

void f_bc068f1a(inout vec4 vertex) {
    f_a5ab46a0(vertex);
    f_b5b95fe7();
    f_5b92effa();
    finalize();
}

void f_a7b5b2d7(inout vec4 vertex) {
    f_a5ab46a0(vertex);
    f_5b92effa();
    f_aad4af2c();
    finalize();
}

void f_43564f9b(inout vec4 vertex) {
    f_b5b95fe7();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_a5ab46a0(vertex);
    finalize();
}

void f_c05c8419(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_aad4af2c();
    f_a5ab46a0(vertex);
    finalize();
}

void f_2ee25078(inout vec4 vertex, float speed) {
    f_a5ab46a0(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_fd275abc(inout vec4 vertex) {
    f_a5ab46a0(vertex);
    f_b5b95fe7();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_3fd892a9(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_b5b95fe7();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_a5ab46a0(vertex);
            f_b5b95fe7();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_bc068f1a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_bc068f1a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_43564f9b(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_43564f9b(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_2ee25078(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_fd275abc(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_f99b6fea(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_bc068f1a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_a7b5b2d7(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_43564f9b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_c05c8419(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_2ee25078(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_f99b6fea(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_bc068f1a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_a7b5b2d7(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_43564f9b(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_c05c8419(vertex);
        return;
    }
    

    
    f_a5ab46a0(vertex);
    f_b5b95fe7();
    finalize();
}