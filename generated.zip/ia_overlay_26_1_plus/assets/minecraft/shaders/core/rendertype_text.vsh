#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_9a751c8b(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_6b0dcde6() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_bde9d3a2(inout vec4 vertex) {
    f_9a751c8b(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_6b0dcde6();
    }
        finalize();
}



void f_2f74721f() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_d448302a() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_90f93167(inout vec4 vertex) {
    f_9a751c8b(vertex);
    f_2f74721f();
    finalize();
}

void f_cc34a119(inout vec4 vertex) {
    f_9a751c8b(vertex);
    f_6b0dcde6();
    f_d448302a();
    finalize();
}

void f_58a3f654(inout vec4 vertex) {
    f_9a751c8b(vertex);
    f_d448302a();
    f_2f74721f();
    finalize();
}

void f_0b5251f4(inout vec4 vertex) {
    f_6b0dcde6();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_9a751c8b(vertex);
    finalize();
}

void f_1b8431fc(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_2f74721f();
    f_9a751c8b(vertex);
    finalize();
}

void f_eb8f5156(inout vec4 vertex, float speed) {
    f_9a751c8b(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_f79de3c9(inout vec4 vertex) {
    f_9a751c8b(vertex);
    f_6b0dcde6();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_bde9d3a2(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_6b0dcde6();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_9a751c8b(vertex);
            f_6b0dcde6();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_cc34a119(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_cc34a119(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_0b5251f4(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_0b5251f4(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_eb8f5156(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_f79de3c9(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_90f93167(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_cc34a119(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_58a3f654(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_0b5251f4(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_1b8431fc(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_eb8f5156(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_90f93167(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_cc34a119(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_58a3f654(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_0b5251f4(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_1b8431fc(vertex);
        return;
    }
    

    
    f_9a751c8b(vertex);
    f_6b0dcde6();
    finalize();
}