#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_f6630f04(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_82dbcac1() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_66812aa7(inout vec4 vertex) {
    f_f6630f04(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_82dbcac1();
    }
        finalize();
}



void f_15b38244() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_c8a18014() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_7f1f8802(inout vec4 vertex) {
    f_f6630f04(vertex);
    f_15b38244();
    finalize();
}

void f_98cef02d(inout vec4 vertex) {
    f_f6630f04(vertex);
    f_82dbcac1();
    f_c8a18014();
    finalize();
}

void f_e9fb5868(inout vec4 vertex) {
    f_f6630f04(vertex);
    f_c8a18014();
    f_15b38244();
    finalize();
}

void f_019f3dc1(inout vec4 vertex) {
    f_82dbcac1();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_f6630f04(vertex);
    finalize();
}

void f_345d9a24(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_15b38244();
    f_f6630f04(vertex);
    finalize();
}

void f_86705a8e(inout vec4 vertex, float speed) {
    f_f6630f04(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_af476037(inout vec4 vertex) {
    f_f6630f04(vertex);
    f_82dbcac1();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_66812aa7(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_82dbcac1();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_f6630f04(vertex);
            f_82dbcac1();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_98cef02d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_98cef02d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_019f3dc1(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_019f3dc1(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_86705a8e(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_af476037(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_7f1f8802(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_98cef02d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_e9fb5868(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_019f3dc1(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_345d9a24(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_86705a8e(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_7f1f8802(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_98cef02d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_e9fb5868(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_019f3dc1(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_345d9a24(vertex);
        return;
    }
    

    
    f_f6630f04(vertex);
    f_82dbcac1();
    finalize();
}