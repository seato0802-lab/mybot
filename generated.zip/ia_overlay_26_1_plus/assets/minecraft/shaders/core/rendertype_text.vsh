#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_7f461312(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_56f7a210() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_7aa1fba0(inout vec4 vertex) {
    f_7f461312(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_56f7a210();
    }
        finalize();
}



void f_f3e6d6df() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_902eeaa3() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_88f5aed9(inout vec4 vertex) {
    f_7f461312(vertex);
    f_f3e6d6df();
    finalize();
}

void f_b88a4658(inout vec4 vertex) {
    f_7f461312(vertex);
    f_56f7a210();
    f_902eeaa3();
    finalize();
}

void f_a8d2ec35(inout vec4 vertex) {
    f_7f461312(vertex);
    f_902eeaa3();
    f_f3e6d6df();
    finalize();
}

void f_6ff3dc63(inout vec4 vertex) {
    f_56f7a210();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_7f461312(vertex);
    finalize();
}

void f_966f4e11(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_f3e6d6df();
    f_7f461312(vertex);
    finalize();
}

void f_1d6dea1c(inout vec4 vertex, float speed) {
    f_7f461312(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_bf8c586a(inout vec4 vertex) {
    f_7f461312(vertex);
    f_56f7a210();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_7aa1fba0(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_56f7a210();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_7f461312(vertex);
            f_56f7a210();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_b88a4658(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_b88a4658(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_6ff3dc63(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_6ff3dc63(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_1d6dea1c(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_bf8c586a(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_88f5aed9(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_b88a4658(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_a8d2ec35(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_6ff3dc63(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_966f4e11(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_1d6dea1c(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_88f5aed9(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_b88a4658(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_a8d2ec35(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_6ff3dc63(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_966f4e11(vertex);
        return;
    }
    

    
    f_7f461312(vertex);
    f_56f7a210();
    finalize();
}