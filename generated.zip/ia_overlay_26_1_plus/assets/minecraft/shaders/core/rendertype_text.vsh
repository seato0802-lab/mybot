#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_80c36131(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_2ff5ce12() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_e8684d5b(inout vec4 vertex) {
    f_80c36131(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_2ff5ce12();
    }
        finalize();
}



void f_7bae93a8() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_b1f3968f() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_424b7f0c(inout vec4 vertex) {
    f_80c36131(vertex);
    f_7bae93a8();
    finalize();
}

void f_7218d4fe(inout vec4 vertex) {
    f_80c36131(vertex);
    f_2ff5ce12();
    f_b1f3968f();
    finalize();
}

void f_91d05ec0(inout vec4 vertex) {
    f_80c36131(vertex);
    f_b1f3968f();
    f_7bae93a8();
    finalize();
}

void f_987096ef(inout vec4 vertex) {
    f_2ff5ce12();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_80c36131(vertex);
    finalize();
}

void f_44df9ebd(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_7bae93a8();
    f_80c36131(vertex);
    finalize();
}

void f_35861041(inout vec4 vertex, float speed) {
    f_80c36131(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_fc337919(inout vec4 vertex) {
    f_80c36131(vertex);
    f_2ff5ce12();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_e8684d5b(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_2ff5ce12();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_80c36131(vertex);
            f_2ff5ce12();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_7218d4fe(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_7218d4fe(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_987096ef(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_987096ef(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_35861041(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_fc337919(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_424b7f0c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_7218d4fe(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_91d05ec0(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_987096ef(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_44df9ebd(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_35861041(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_424b7f0c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_7218d4fe(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_91d05ec0(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_987096ef(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_44df9ebd(vertex);
        return;
    }
    

    
    f_80c36131(vertex);
    f_2ff5ce12();
    finalize();
}