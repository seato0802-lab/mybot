#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_da554b07(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_8f34356d() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_29693184(inout vec4 vertex) {
    f_da554b07(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_8f34356d();
    }
        finalize();
}



void f_396e0590() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_4f412435() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_aa759fb1(inout vec4 vertex) {
    f_da554b07(vertex);
    f_396e0590();
    finalize();
}

void f_26a934c8(inout vec4 vertex) {
    f_da554b07(vertex);
    f_8f34356d();
    f_4f412435();
    finalize();
}

void f_1ac9ec57(inout vec4 vertex) {
    f_da554b07(vertex);
    f_4f412435();
    f_396e0590();
    finalize();
}

void f_5264e858(inout vec4 vertex) {
    f_8f34356d();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_da554b07(vertex);
    finalize();
}

void f_d2d09949(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_396e0590();
    f_da554b07(vertex);
    finalize();
}

void f_1a02eb6c(inout vec4 vertex, float speed) {
    f_da554b07(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_4c770f87(inout vec4 vertex) {
    f_da554b07(vertex);
    f_8f34356d();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_29693184(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_8f34356d();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_da554b07(vertex);
            f_8f34356d();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_26a934c8(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_26a934c8(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_5264e858(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_5264e858(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_1a02eb6c(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_4c770f87(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_aa759fb1(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_26a934c8(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_1ac9ec57(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_5264e858(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_d2d09949(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_1a02eb6c(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_aa759fb1(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_26a934c8(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_1ac9ec57(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_5264e858(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_d2d09949(vertex);
        return;
    }
    

    
    f_da554b07(vertex);
    f_8f34356d();
    finalize();
}