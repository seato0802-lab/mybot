#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_917a6962(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_b7f23e4a() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_bc3b719f(inout vec4 vertex) {
    f_917a6962(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_b7f23e4a();
    }
        finalize();
}



void f_bfbee221() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_e5afa226() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_ea8e0162(inout vec4 vertex) {
    f_917a6962(vertex);
    f_bfbee221();
    finalize();
}

void f_770c050a(inout vec4 vertex) {
    f_917a6962(vertex);
    f_b7f23e4a();
    f_e5afa226();
    finalize();
}

void f_c95bede6(inout vec4 vertex) {
    f_917a6962(vertex);
    f_e5afa226();
    f_bfbee221();
    finalize();
}

void f_cf0c6962(inout vec4 vertex) {
    f_b7f23e4a();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_917a6962(vertex);
    finalize();
}

void f_3c1d603d(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_bfbee221();
    f_917a6962(vertex);
    finalize();
}

void f_e6466dbf(inout vec4 vertex, float speed) {
    f_917a6962(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_d4790e54(inout vec4 vertex) {
    f_917a6962(vertex);
    f_b7f23e4a();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_bc3b719f(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_b7f23e4a();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_917a6962(vertex);
            f_b7f23e4a();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_770c050a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_770c050a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_cf0c6962(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_cf0c6962(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_e6466dbf(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_d4790e54(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_ea8e0162(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_770c050a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_c95bede6(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_cf0c6962(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_3c1d603d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_e6466dbf(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_ea8e0162(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_770c050a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_c95bede6(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_cf0c6962(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_3c1d603d(vertex);
        return;
    }
    

    
    f_917a6962(vertex);
    f_b7f23e4a();
    finalize();
}