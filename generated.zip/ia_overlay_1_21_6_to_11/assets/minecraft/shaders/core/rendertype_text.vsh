#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_a1a8c8ed(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_61031064() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_32f4dd20(inout vec4 vertex) {
    f_a1a8c8ed(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_61031064();
    }
    finalize();
}



void f_b1a618ad() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_7bc1e1a9() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_90c990ce(inout vec4 vertex) {
    f_a1a8c8ed(vertex);
    f_b1a618ad();
    finalize();
}

void f_78c20e18(inout vec4 vertex) {
    f_a1a8c8ed(vertex);
    f_61031064();
    f_7bc1e1a9();
    finalize();
}

void f_47d5407c(inout vec4 vertex) {
    f_a1a8c8ed(vertex);
    f_7bc1e1a9();
    f_b1a618ad();
    finalize();
}

void f_c07031bf(inout vec4 vertex) {
    f_61031064();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_a1a8c8ed(vertex);
    finalize();
}

void f_5e38e81c(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_b1a618ad();
    f_a1a8c8ed(vertex);
    finalize();
}

void f_116e2f41(inout vec4 vertex, float speed) {
    f_a1a8c8ed(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_b34e8868(inout vec4 vertex) {
    f_a1a8c8ed(vertex);
    f_61031064();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_32f4dd20(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_61031064();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_a1a8c8ed(vertex);
            f_61031064();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_78c20e18(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_78c20e18(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_c07031bf(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_c07031bf(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_116e2f41(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_b34e8868(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_90c990ce(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_78c20e18(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_47d5407c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_c07031bf(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_5e38e81c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_116e2f41(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_90c990ce(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_78c20e18(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_47d5407c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_c07031bf(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_5e38e81c(vertex);
        return;
    }
    

    
    f_a1a8c8ed(vertex);
    f_61031064();
    finalize();
}