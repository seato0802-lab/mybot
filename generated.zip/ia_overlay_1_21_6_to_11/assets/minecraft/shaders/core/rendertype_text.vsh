#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_c0441aaa(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_de24e50b() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_0a8d045d(inout vec4 vertex) {
    f_c0441aaa(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_de24e50b();
    }
    finalize();
}



void f_53da1216() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_c6226e79() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_026cf195(inout vec4 vertex) {
    f_c0441aaa(vertex);
    f_53da1216();
    finalize();
}

void f_724d586d(inout vec4 vertex) {
    f_c0441aaa(vertex);
    f_de24e50b();
    f_c6226e79();
    finalize();
}

void f_de127c91(inout vec4 vertex) {
    f_c0441aaa(vertex);
    f_c6226e79();
    f_53da1216();
    finalize();
}

void f_b54d133f(inout vec4 vertex) {
    f_de24e50b();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_c0441aaa(vertex);
    finalize();
}

void f_5f914d19(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_53da1216();
    f_c0441aaa(vertex);
    finalize();
}

void f_cc34b724(inout vec4 vertex, float speed) {
    f_c0441aaa(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_53a8104c(inout vec4 vertex) {
    f_c0441aaa(vertex);
    f_de24e50b();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_0a8d045d(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_de24e50b();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_c0441aaa(vertex);
            f_de24e50b();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_724d586d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_724d586d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_b54d133f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_b54d133f(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_cc34b724(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_53a8104c(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_026cf195(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_724d586d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_de127c91(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_b54d133f(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_5f914d19(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_cc34b724(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_026cf195(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_724d586d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_de127c91(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_b54d133f(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_5f914d19(vertex);
        return;
    }
    

    
    f_c0441aaa(vertex);
    f_de24e50b();
    finalize();
}