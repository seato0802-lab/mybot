#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_0d3a5275(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_517f6425() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_6f08bbfd(inout vec4 vertex) {
    f_0d3a5275(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_517f6425();
    }
    finalize();
}



void f_2b4ca6da() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_03aaab1e() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_04aa8fc9(inout vec4 vertex) {
    f_0d3a5275(vertex);
    f_2b4ca6da();
    finalize();
}

void f_a01d61c8(inout vec4 vertex) {
    f_0d3a5275(vertex);
    f_517f6425();
    f_03aaab1e();
    finalize();
}

void f_b5c70af8(inout vec4 vertex) {
    f_0d3a5275(vertex);
    f_03aaab1e();
    f_2b4ca6da();
    finalize();
}

void f_f0c9e44c(inout vec4 vertex) {
    f_517f6425();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_0d3a5275(vertex);
    finalize();
}

void f_e6032934(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_2b4ca6da();
    f_0d3a5275(vertex);
    finalize();
}

void f_895b42ab(inout vec4 vertex, float speed) {
    f_0d3a5275(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_292728aa(inout vec4 vertex) {
    f_0d3a5275(vertex);
    f_517f6425();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_6f08bbfd(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_517f6425();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_0d3a5275(vertex);
            f_517f6425();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_a01d61c8(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_a01d61c8(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_f0c9e44c(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_f0c9e44c(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_895b42ab(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_292728aa(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_04aa8fc9(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_a01d61c8(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_b5c70af8(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_f0c9e44c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_e6032934(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_895b42ab(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_04aa8fc9(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_a01d61c8(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_b5c70af8(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_f0c9e44c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_e6032934(vertex);
        return;
    }
    

    
    f_0d3a5275(vertex);
    f_517f6425();
    finalize();
}