#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_19f4600c(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_d54fda2c() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_5f810f04(inout vec4 vertex) {
    f_19f4600c(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_d54fda2c();
    }
    finalize();
}



void f_eef20306() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_7ed6e9b5() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_9b94642d(inout vec4 vertex) {
    f_19f4600c(vertex);
    f_eef20306();
    finalize();
}

void f_dc65e72d(inout vec4 vertex) {
    f_19f4600c(vertex);
    f_d54fda2c();
    f_7ed6e9b5();
    finalize();
}

void f_1697ec1e(inout vec4 vertex) {
    f_19f4600c(vertex);
    f_7ed6e9b5();
    f_eef20306();
    finalize();
}

void f_4c4cffd5(inout vec4 vertex) {
    f_d54fda2c();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_19f4600c(vertex);
    finalize();
}

void f_367a8bce(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_eef20306();
    f_19f4600c(vertex);
    finalize();
}

void f_2cf4aa00(inout vec4 vertex, float speed) {
    f_19f4600c(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_417d725b(inout vec4 vertex) {
    f_19f4600c(vertex);
    f_d54fda2c();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_5f810f04(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_d54fda2c();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_19f4600c(vertex);
            f_d54fda2c();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_dc65e72d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_dc65e72d(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_4c4cffd5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_4c4cffd5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_2cf4aa00(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_417d725b(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_9b94642d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_dc65e72d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_1697ec1e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_4c4cffd5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_367a8bce(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_2cf4aa00(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_9b94642d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_dc65e72d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_1697ec1e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_4c4cffd5(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_367a8bce(vertex);
        return;
    }
    

    
    f_19f4600c(vertex);
    f_d54fda2c();
    finalize();
}