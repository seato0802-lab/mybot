#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_af45dc4d(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_d3307257() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_66667615(inout vec4 vertex) {
    f_af45dc4d(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_d3307257();
    }
    finalize();
}



void f_4bd977d3() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_2e6bfe10() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_b9dc976d(inout vec4 vertex) {
    f_af45dc4d(vertex);
    f_4bd977d3();
    finalize();
}

void f_863f3622(inout vec4 vertex) {
    f_af45dc4d(vertex);
    f_d3307257();
    f_2e6bfe10();
    finalize();
}

void f_e90398dc(inout vec4 vertex) {
    f_af45dc4d(vertex);
    f_2e6bfe10();
    f_4bd977d3();
    finalize();
}

void f_7bee7e0e(inout vec4 vertex) {
    f_d3307257();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_af45dc4d(vertex);
    finalize();
}

void f_8055eee6(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_4bd977d3();
    f_af45dc4d(vertex);
    finalize();
}

void f_66becd50(inout vec4 vertex, float speed) {
    f_af45dc4d(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_83e4df3c(inout vec4 vertex) {
    f_af45dc4d(vertex);
    f_d3307257();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_66667615(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_d3307257();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_af45dc4d(vertex);
            f_d3307257();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_863f3622(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_863f3622(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_7bee7e0e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_7bee7e0e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_66becd50(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_83e4df3c(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_b9dc976d(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_863f3622(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_e90398dc(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_7bee7e0e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_8055eee6(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_66becd50(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_b9dc976d(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_863f3622(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_e90398dc(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_7bee7e0e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_8055eee6(vertex);
        return;
    }
    

    
    f_af45dc4d(vertex);
    f_d3307257();
    finalize();
}