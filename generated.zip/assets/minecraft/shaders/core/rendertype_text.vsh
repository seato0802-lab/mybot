#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_2ecc67fd(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_5079af29() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_59dd350e(inout vec4 vertex) {
    f_2ecc67fd(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_5079af29();
    }
    finalize();
}



void f_145974a2() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_7e175d82() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_7b425ea3(inout vec4 vertex) {
    f_2ecc67fd(vertex);
    f_145974a2();
    finalize();
}

void f_dc107d91(inout vec4 vertex) {
    f_2ecc67fd(vertex);
    f_5079af29();
    f_7e175d82();
    finalize();
}

void f_b20cad79(inout vec4 vertex) {
    f_2ecc67fd(vertex);
    f_7e175d82();
    f_145974a2();
    finalize();
}

void f_7170770e(inout vec4 vertex) {
    f_5079af29();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_2ecc67fd(vertex);
    finalize();
}

void f_506db053(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_145974a2();
    f_2ecc67fd(vertex);
    finalize();
}

void f_ab409125(inout vec4 vertex, float speed) {
    f_2ecc67fd(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_a3e7c958(inout vec4 vertex) {
    f_2ecc67fd(vertex);
    f_5079af29();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_59dd350e(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_5079af29();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_2ecc67fd(vertex);
            f_5079af29();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_dc107d91(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_dc107d91(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_7170770e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_7170770e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_ab409125(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_a3e7c958(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_7b425ea3(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_dc107d91(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_b20cad79(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_7170770e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_506db053(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_ab409125(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_7b425ea3(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_dc107d91(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_b20cad79(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_7170770e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_506db053(vertex);
        return;
    }
    

    
    f_2ecc67fd(vertex);
    f_5079af29();
    finalize();
}