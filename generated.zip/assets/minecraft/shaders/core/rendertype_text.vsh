#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_19d9a1e5(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_1420e57d() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_a263129d(inout vec4 vertex) {
    f_19d9a1e5(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_1420e57d();
    }
    finalize();
}



void f_e582b828() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_439d4c72() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_2b4be1fc(inout vec4 vertex) {
    f_19d9a1e5(vertex);
    f_e582b828();
    finalize();
}

void f_c6d8b7ec(inout vec4 vertex) {
    f_19d9a1e5(vertex);
    f_1420e57d();
    f_439d4c72();
    finalize();
}

void f_d15656cc(inout vec4 vertex) {
    f_19d9a1e5(vertex);
    f_439d4c72();
    f_e582b828();
    finalize();
}

void f_b4ff1684(inout vec4 vertex) {
    f_1420e57d();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_19d9a1e5(vertex);
    finalize();
}

void f_4618c11e(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_e582b828();
    f_19d9a1e5(vertex);
    finalize();
}

void f_d6584f50(inout vec4 vertex, float speed) {
    f_19d9a1e5(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_cb47b483(inout vec4 vertex) {
    f_19d9a1e5(vertex);
    f_1420e57d();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_a263129d(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_1420e57d();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_19d9a1e5(vertex);
            f_1420e57d();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_c6d8b7ec(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_c6d8b7ec(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_b4ff1684(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_b4ff1684(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_d6584f50(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_cb47b483(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_2b4be1fc(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_c6d8b7ec(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_d15656cc(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_b4ff1684(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_4618c11e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_d6584f50(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_2b4be1fc(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_c6d8b7ec(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_d15656cc(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_b4ff1684(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_4618c11e(vertex);
        return;
    }
    

    
    f_19d9a1e5(vertex);
    f_1420e57d();
    finalize();
}