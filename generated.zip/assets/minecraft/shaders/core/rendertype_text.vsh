#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_99592e18(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_24378ab4() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_a013f0ba(inout vec4 vertex) {
    f_99592e18(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_24378ab4();
    }
    finalize();
}



void f_84f4d4f8() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_dc9dc85c() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_0e961458(inout vec4 vertex) {
    f_99592e18(vertex);
    f_84f4d4f8();
    finalize();
}

void f_50ac5361(inout vec4 vertex) {
    f_99592e18(vertex);
    f_24378ab4();
    f_dc9dc85c();
    finalize();
}

void f_5e20d284(inout vec4 vertex) {
    f_99592e18(vertex);
    f_dc9dc85c();
    f_84f4d4f8();
    finalize();
}

void f_ae9993af(inout vec4 vertex) {
    f_24378ab4();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_99592e18(vertex);
    finalize();
}

void f_3bc28bf2(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_84f4d4f8();
    f_99592e18(vertex);
    finalize();
}

void f_60a57ccc(inout vec4 vertex, float speed) {
    f_99592e18(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_e4cc87d2(inout vec4 vertex) {
    f_99592e18(vertex);
    f_24378ab4();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_a013f0ba(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_24378ab4();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_99592e18(vertex);
            f_24378ab4();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_50ac5361(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_50ac5361(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_ae9993af(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_ae9993af(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_60a57ccc(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_e4cc87d2(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_0e961458(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_50ac5361(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_5e20d284(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_ae9993af(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_3bc28bf2(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_60a57ccc(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_0e961458(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_50ac5361(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_5e20d284(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_ae9993af(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_3bc28bf2(vertex);
        return;
    }
    

    
    f_99592e18(vertex);
    f_24378ab4();
    finalize();
}