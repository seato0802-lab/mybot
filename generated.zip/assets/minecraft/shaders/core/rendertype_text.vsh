#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_7b1b8959(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_508ac9f0() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_e41eaa52(inout vec4 vertex) {
    f_7b1b8959(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_508ac9f0();
    }
    finalize();
}



void f_9d6af2f0() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_6fa6864f() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_49fbb1e4(inout vec4 vertex) {
    f_7b1b8959(vertex);
    f_9d6af2f0();
    finalize();
}

void f_568ab8da(inout vec4 vertex) {
    f_7b1b8959(vertex);
    f_508ac9f0();
    f_6fa6864f();
    finalize();
}

void f_73633a19(inout vec4 vertex) {
    f_7b1b8959(vertex);
    f_6fa6864f();
    f_9d6af2f0();
    finalize();
}

void f_32cb86cc(inout vec4 vertex) {
    f_508ac9f0();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_7b1b8959(vertex);
    finalize();
}

void f_d7774c76(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_9d6af2f0();
    f_7b1b8959(vertex);
    finalize();
}

void f_850c2c6f(inout vec4 vertex, float speed) {
    f_7b1b8959(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_84733bb8(inout vec4 vertex) {
    f_7b1b8959(vertex);
    f_508ac9f0();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_e41eaa52(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_508ac9f0();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_7b1b8959(vertex);
            f_508ac9f0();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_568ab8da(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_568ab8da(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_32cb86cc(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_32cb86cc(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_850c2c6f(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_84733bb8(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_49fbb1e4(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_568ab8da(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_73633a19(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_32cb86cc(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_d7774c76(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_850c2c6f(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_49fbb1e4(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_568ab8da(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_73633a19(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_32cb86cc(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_d7774c76(vertex);
        return;
    }
    

    
    f_7b1b8959(vertex);
    f_508ac9f0();
    finalize();
}