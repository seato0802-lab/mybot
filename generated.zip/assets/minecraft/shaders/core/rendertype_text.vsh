#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_433ba784(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_d76ee439() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_19e82335(inout vec4 vertex) {
    f_433ba784(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_d76ee439();
    }
    finalize();
}



void f_63994d01() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_24e59f27() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_0f98bbeb(inout vec4 vertex) {
    f_433ba784(vertex);
    f_63994d01();
    finalize();
}

void f_7f477f53(inout vec4 vertex) {
    f_433ba784(vertex);
    f_d76ee439();
    f_24e59f27();
    finalize();
}

void f_4abc1e4c(inout vec4 vertex) {
    f_433ba784(vertex);
    f_24e59f27();
    f_63994d01();
    finalize();
}

void f_69ae674e(inout vec4 vertex) {
    f_d76ee439();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_433ba784(vertex);
    finalize();
}

void f_cc7c0a28(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_63994d01();
    f_433ba784(vertex);
    finalize();
}

void f_521864c2(inout vec4 vertex, float speed) {
    f_433ba784(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_6da0b0a6(inout vec4 vertex) {
    f_433ba784(vertex);
    f_d76ee439();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_19e82335(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_d76ee439();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_433ba784(vertex);
            f_d76ee439();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_7f477f53(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_7f477f53(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_69ae674e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_69ae674e(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_521864c2(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_6da0b0a6(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_0f98bbeb(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_7f477f53(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_4abc1e4c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_69ae674e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_cc7c0a28(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_521864c2(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_0f98bbeb(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_7f477f53(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_4abc1e4c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_69ae674e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_cc7c0a28(vertex);
        return;
    }
    

    
    f_433ba784(vertex);
    f_d76ee439();
    finalize();
}