#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_22a62075(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_e9bc9b9d() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_a6b2fbb0(inout vec4 vertex) {
    f_22a62075(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_e9bc9b9d();
    }
    finalize();
}



void f_9df588c8() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_f0dc816a() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_bec542b2(inout vec4 vertex) {
    f_22a62075(vertex);
    f_9df588c8();
    finalize();
}

void f_5f623643(inout vec4 vertex) {
    f_22a62075(vertex);
    f_e9bc9b9d();
    f_f0dc816a();
    finalize();
}

void f_6bdcb346(inout vec4 vertex) {
    f_22a62075(vertex);
    f_f0dc816a();
    f_9df588c8();
    finalize();
}

void f_62565cf5(inout vec4 vertex) {
    f_e9bc9b9d();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_22a62075(vertex);
    finalize();
}

void f_610bf210(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_9df588c8();
    f_22a62075(vertex);
    finalize();
}

void f_441cc6ea(inout vec4 vertex, float speed) {
    f_22a62075(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_3af3ca23(inout vec4 vertex) {
    f_22a62075(vertex);
    f_e9bc9b9d();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_a6b2fbb0(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_e9bc9b9d();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_22a62075(vertex);
            f_e9bc9b9d();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_5f623643(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_5f623643(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_62565cf5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_62565cf5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_441cc6ea(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_3af3ca23(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_bec542b2(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_5f623643(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_6bdcb346(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_62565cf5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_610bf210(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_441cc6ea(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_bec542b2(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_5f623643(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_6bdcb346(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_62565cf5(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_610bf210(vertex);
        return;
    }
    

    
    f_22a62075(vertex);
    f_e9bc9b9d();
    finalize();
}