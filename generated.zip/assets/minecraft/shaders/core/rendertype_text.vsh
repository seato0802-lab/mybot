#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_ec8f0b1e(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_fdb041b5() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_290a6924(inout vec4 vertex) {
    f_ec8f0b1e(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_fdb041b5();
    }
    finalize();
}



void f_cf2453f5() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_08ff086b() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_6e680a66(inout vec4 vertex) {
    f_ec8f0b1e(vertex);
    f_cf2453f5();
    finalize();
}

void f_7a2f71de(inout vec4 vertex) {
    f_ec8f0b1e(vertex);
    f_fdb041b5();
    f_08ff086b();
    finalize();
}

void f_fb00038a(inout vec4 vertex) {
    f_ec8f0b1e(vertex);
    f_08ff086b();
    f_cf2453f5();
    finalize();
}

void f_f5089cc8(inout vec4 vertex) {
    f_fdb041b5();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_ec8f0b1e(vertex);
    finalize();
}

void f_e84454fe(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_cf2453f5();
    f_ec8f0b1e(vertex);
    finalize();
}

void f_aba9fd2a(inout vec4 vertex, float speed) {
    f_ec8f0b1e(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_aaf5d1b7(inout vec4 vertex) {
    f_ec8f0b1e(vertex);
    f_fdb041b5();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_290a6924(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_fdb041b5();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_ec8f0b1e(vertex);
            f_fdb041b5();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_7a2f71de(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_7a2f71de(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_f5089cc8(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_f5089cc8(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_aba9fd2a(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_aaf5d1b7(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_6e680a66(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_7a2f71de(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_fb00038a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_f5089cc8(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_e84454fe(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_aba9fd2a(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_6e680a66(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_7a2f71de(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_fb00038a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_f5089cc8(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_e84454fe(vertex);
        return;
    }
    

    
    f_ec8f0b1e(vertex);
    f_fdb041b5();
    finalize();
}