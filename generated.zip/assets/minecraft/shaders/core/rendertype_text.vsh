#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_576a946d(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_d3d2c8c7() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_7ff87ac7(inout vec4 vertex) {
    f_576a946d(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_d3d2c8c7();
    }
    finalize();
}



void f_71c8f715() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_c19f6eeb() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_a6683e21(inout vec4 vertex) {
    f_576a946d(vertex);
    f_71c8f715();
    finalize();
}

void f_92329c51(inout vec4 vertex) {
    f_576a946d(vertex);
    f_d3d2c8c7();
    f_c19f6eeb();
    finalize();
}

void f_08c9044b(inout vec4 vertex) {
    f_576a946d(vertex);
    f_c19f6eeb();
    f_71c8f715();
    finalize();
}

void f_24f23a79(inout vec4 vertex) {
    f_d3d2c8c7();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_576a946d(vertex);
    finalize();
}

void f_9a54ea09(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_71c8f715();
    f_576a946d(vertex);
    finalize();
}

void f_07129f62(inout vec4 vertex, float speed) {
    f_576a946d(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_99e41d4f(inout vec4 vertex) {
    f_576a946d(vertex);
    f_d3d2c8c7();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_7ff87ac7(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_d3d2c8c7();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_576a946d(vertex);
            f_d3d2c8c7();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_92329c51(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_92329c51(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_24f23a79(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_24f23a79(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_07129f62(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_99e41d4f(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_a6683e21(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_92329c51(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_08c9044b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_24f23a79(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_9a54ea09(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_07129f62(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_a6683e21(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_92329c51(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_08c9044b(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_24f23a79(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_9a54ea09(vertex);
        return;
    }
    

    
    f_576a946d(vertex);
    f_d3d2c8c7();
    finalize();
}