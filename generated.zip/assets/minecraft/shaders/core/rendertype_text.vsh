#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_720a07be(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_4fcdbfc3() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_161c368f(inout vec4 vertex) {
    f_720a07be(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_4fcdbfc3();
    }
    finalize();
}



void f_99cc81d6() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_bc30e170() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_d21b6d6e(inout vec4 vertex) {
    f_720a07be(vertex);
    f_99cc81d6();
    finalize();
}

void f_eb98d8e5(inout vec4 vertex) {
    f_720a07be(vertex);
    f_4fcdbfc3();
    f_bc30e170();
    finalize();
}

void f_b8388bf8(inout vec4 vertex) {
    f_720a07be(vertex);
    f_bc30e170();
    f_99cc81d6();
    finalize();
}

void f_dda57789(inout vec4 vertex) {
    f_4fcdbfc3();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_720a07be(vertex);
    finalize();
}

void f_8c0a7657(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_99cc81d6();
    f_720a07be(vertex);
    finalize();
}

void f_c4ac9fa8(inout vec4 vertex, float speed) {
    f_720a07be(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_27efa7b4(inout vec4 vertex) {
    f_720a07be(vertex);
    f_4fcdbfc3();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_161c368f(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_4fcdbfc3();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_720a07be(vertex);
            f_4fcdbfc3();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_eb98d8e5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_eb98d8e5(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_dda57789(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_dda57789(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_c4ac9fa8(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_27efa7b4(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_d21b6d6e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_eb98d8e5(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_b8388bf8(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_dda57789(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_8c0a7657(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_c4ac9fa8(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_d21b6d6e(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_eb98d8e5(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_b8388bf8(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_dda57789(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_8c0a7657(vertex);
        return;
    }
    

    
    f_720a07be(vertex);
    f_4fcdbfc3();
    finalize();
}